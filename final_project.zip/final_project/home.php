<?php
session_start();

// If user is not logged in, redirect to login page
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pet Havens Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background: #2d6a4f;
            padding: 15px;
            color: white;
            font-size: 22px;
            text-align: center;
        }

        .container {
            width: 80%;
            margin: auto;
            margin-top: 40px;
        }

        .card {
            background: white;
            padding: 25px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0px 3px 6px rgba(0,0,0,0.1);
        }

        .card h2 {
            margin-top: 0;
            color: #2d6a4f;
        }

        .menu-buttons {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .menu-buttons a {
            text-decoration: none;
            background: #40916c;
            padding: 12px 20px;
            border-radius: 8px;
            color: white;
            font-size: 16px;
            transition: 0.3s;
        }

        .menu-buttons a:hover {
            background: #1b4332;
        }

        .logout {
            text-align: right;
            margin-top: 10px;
        }

        .logout a {
            color: #d00000;
            text-decoration: none;
            font-weight: bold;
        }

        .logout a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="navbar">
    🐾 Pet Havens Dashboard
</div>

<div class="container">

    <div class="logout">
        <a href="logout.php">Logout</a>
    </div>

    <div class="card">
        <h2>Welcome, <?php echo $_SESSION["email"]; ?>!</h2>
        <p>You are now logged in. Use the options below to manage or browse the pet store.</p>
    </div>

    <div class="card">
        <h2>Store Menu</h2>
        <div class="menu-buttons">
            <a href="#">View All Pets</a>
            <a href="#">View Products</a>
            <a href="#">Your Orders</a>
            <a href="#">Profile Settings</a>
        </div>
    </div>

</div>

</body>
</html>

